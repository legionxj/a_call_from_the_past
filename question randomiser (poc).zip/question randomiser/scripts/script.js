/*
var questions = [
    "questions/question 1 (marthe).mp3",
    "questions/question 2 (marthe).mp3",
    "questions/question 3 (marthe).mp3",
    "questions/question 4 (marthe).mp3",
    "questions/question 5 (marthe).mp3",
    "questions/question 1 (vi).mp3",
    "questions/question 2 (vi).mp3",
    "questions/question 3 (vi).mp3",
    "questions/question 4 (vi).mp3",
    "questions/question 5 (vi).mp3",
    "questions/question 1 (sophie).mp3",
    "questions/question 2 (sophie).mp3",
    "questions/question 3 (sophie).mp3",
    "questions/question 4 (sophie).mp3",
    "questions/question 5 (sophie).mp3",
    "questions/question 1 (noah).mp3",
    "questions/question 2 (noah).mp3",
    "questions/question 3 (noah).mp3",
    "questions/question 4 (noah).mp3",
    "questions/question 5 (noah).mp3"
    // Add more WAV file paths as needed
];

// Add event listener to button
document.getElementById("playBtn").addEventListener("click", function() {
    playRandomAudio();
});

// Function to play a random audio
function playRandomAudio() {
    // Get a random index
    var randomIndex = Math.floor(Math.random() * questions.length);
    // Get the audio source corresponding to the random index
    var audioSrc = questions[randomIndex];
    // Create and play the audio
    var audio = new Audio(audioSrc);
    audio.play();
}





// this is a different code





var questions = [
    "questions/question 1 (marthe).mp3",
    "questions/question 2 (marthe).mp3",
    "questions/question 3 (marthe).mp3",
    "questions/question 4 (marthe).mp3",
    "questions/question 5 (marthe).mp3",
    "questions/question 1 (vi).mp3",
    "questions/question 2 (vi).mp3",
    "questions/question 3 (vi).mp3",
    "questions/question 4 (vi).mp3",
    "questions/question 5 (vi).mp3",
    "questions/question 1 (sophie).mp3",
    "questions/question 2 (sophie).mp3",
    "questions/question 3 (sophie).mp3",
    "questions/question 4 (sophie).mp3",
    "questions/question 5 (sophie).mp3",
    "questions/question 1 (noah).mp3",
    "questions/question 2 (noah).mp3",
    "questions/question 3 (noah).mp3",
    "questions/question 4 (noah).mp3",
    "questions/question 5 (noah).mp3",
    // Add more WAV file paths as needed
];

// Add event listener to button
document.getElementById("playBtn").addEventListener("click", function() {
    playRandomAudio();
});

// Function to play a random audio
function playRandomAudio() {
    // Get a random index
    var randomIndex = Math.floor(Math.random() * questions.length);
    // Get the audio source corresponding to the random index
    var audioSrc = questions[randomIndex];
    // Create and play the audio
    var audio = new Audio(audioSrc);
    audio.play();
}

let socket = new WebSocket("ws://192.168.100.1:1880/ws");

socket.onopen = function(e) {
  console.log("[open] Connection established");
};

socket.onmessage = function(event) {
  console.log(`[message] Data received from server: ${event.data}`);

    // your code


};



// Client-side code (Raspberry Pi)

// Set up WebSocket connection
let socket = new WebSocket("ws://192.168.100.1:1880/ws");

socket.onopen = function(e) {
  console.log("[open] Connection established");
};

// Function to handle button press event
function handleButtonPress() {
    // Send a message over WebSocket to server
    socket.send("Button pressed");
}

// Add event listener to button for handling button press
document.getElementById("yourButtonId").addEventListener("click", handleButtonPress);

// Handle WebSocket messages from the server
socket.onmessage = function(event) {
    console.log(`[message] Data received from server: ${event.data}`);
    // Assuming server sends back the randomized array list
    var randomizedQuestions = JSON.parse(event.data);
    // Use the randomizedQuestions array as needed
    // For example, you can call your existing function playRandomAudio() with this array
    playRandomAudio(randomizedQuestions);
};

// Function to play random audio from the provided array
function playRandomAudio(questionsArray) {
    var randomIndex = Math.floor(Math.random() * questionsArray.length);
    var audioSrc = questionsArray[randomIndex];
    var audio = new Audio(audioSrc);
    audio.play();
}


// Server-side code (Node.js)

const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: 1880 });

// Array of questions
var questions = [
    "questions/question 1 (marthe).wav",
    "questions/question 2 (marthe).wav",
    "questions/question 3 (marthe).wav",
    "questions/question 4 (marthe).wav",
    "questions/question 5 (marthe).wav"
];

// Function to send a message to all connected clients
function sendRandomizedQuestions() {
    // Randomize the array
    var randomizedQuestions = shuffleArray(questions);
    // Convert to JSON before sending
    var jsonQuestions = JSON.stringify(randomizedQuestions);
    wss.clients.forEach(function each(client) {
        if (client.readyState === WebSocket.OPEN) {
            client.send(jsonQuestions);
        }
    });
}

// Function to shuffle an array (Fisher-Yates algorithm)
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

// WebSocket connection handling
wss.on('connection', function connection(ws) {
    console.log('Client connected');
    // Handle incoming messages from clients (assuming button press message)
    ws.on('message', function incoming(message) {
        console.log('Received message from client:', message);
        // On receiving message, send randomized questions array to the client
        sendRandomizedQuestions();
    });
});

*/